  
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <?php echo $__env->make('user.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/login-register.css')); ?>">
    <title>Login</title>
  </head>
  <body>
  <?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
 <div class="form-cont"  id="sign-in-form">
   
        <div class="frm-header">
            <h4>Sign In</h4>
        </div>
        <?php if(Session::has('invalid')): ?>
        <div class="alert alert-danger alert-dismissible fade show alert-error" role="alert">
          <?php echo e(Session::get('invalid')); ?>

         
         </div>
        <?php endif; ?>
        <div class="login">
        <div class="bdy">
        <form method="GET" action="/login-attempt">
            <?php echo csrf_field(); ?>
                <div class="rgster-form1">
                <input type="text" name="user"class="form-control" id="email" aria-describedby="emailHelp" placeholder="Username">
                <span><?php echo e($errors->first('user')); ?></span>
                </div>
                <div class="rgster-form1">
                <input type="password" class="form-control" name="pass" id="password" placeholder="Password">
                <span><?php echo e($errors->first('pass')); ?></span>
                </div>
                <div class="">
                <button type="submit" class="btn btn-dark">Login</button>
                </div>
                <div class="sign-up">
                    <span>Not Registered Yet? </span><span id="sign-up" onClick="sign_up()">Sign Up</span>
                </div>
            </form>
        </div>
    </div>
 </div>
 <div class="form-cont-r"  id="sign-up-form">
        <div class="frm-header">
            <h4>Sign Up</h4>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show alert-error" role="alert">
            <?php echo e(Session::get('message')); ?>

         </div>
    <?php endif; ?>
 <div class="sign-up">
        <div class="bdy">
        <form action="/register" method="get">
            <?php echo csrf_field(); ?>
                <div class="rgster-form">
                <input type="text" name="username" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Username">
                <span><?php echo e($errors->first('username')); ?></span>
                </div>
                <div class="rgster-form">
                <input type="text" name="fullname" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Full Name">
                <span><?php echo e($errors->first('fullname')); ?></span>
                </div>
                <div class="rgster-form">
                <input type="text" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email">
                <span><?php echo e($errors->first('email')); ?></span>
                </div>
                <div class="rgster-form">
                <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                <span><?php echo e($errors->first('password')); ?></span>
                </div>
                <div class="rgster-form">
                <input type="password" name="password_confirmation" class="form-control" id="password" placeholder="Confirm Password">
                </div>
                <div class="rgster-form">
                <button type="submit" class="btn btn-dark">Register</button>
                </div>
                <div class="register">
                    <span>Already Registered? </span><span id="sign-in" onClick="sign_in()">Sign In</span>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="l-footer">
<span>©Mapasakatan Creator</span>
</div>
  <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <script>
    function sign_in() {
       localStorage.setItem("show","sign-in");
        document.getElementById("sign-up-form").style.display = "none";
        document.getElementById("sign-in-form").style.display = "block";
        localStorage.setItem("show","sign-in");
    }
    function sign_up() {
        localStorage.setItem("show","sign-up");
        document.getElementById("sign-in-form").style.display = "none";
        document.getElementById("sign-up-form").style.display = "block";
       
    }
if (localStorage.getItem("show")=='sign-up') {
    document.getElementById("sign-in-form").style.display = "none";
    document.getElementById("sign-up-form").style.display = "block";
}else {
    document.getElementById("sign-up-form").style.display = "none";
    document.getElementById("sign-in-form").style.display = "block";
}

  </script>   
  </body>
  </html>
  
<?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/login-register.blade.php ENDPATH**/ ?>