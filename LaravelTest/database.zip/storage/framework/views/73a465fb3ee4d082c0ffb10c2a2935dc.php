
<div class="navbar">
  <i class='bx bxs-cat e-logo'><span>WPets</span></i>
  <ul>
    <li><a href="/" class="tgl hver">Home</a></li>
    <li><a href="#about"  class="tgl">Product</a></li>
    <li><a href="#education" class="tgl">About</a></li>
    <li><a href="#skills" class="tgl">Contact</a></li>
  </ul>
  <div class="left">
    <input type="email" class="search-bar" id="exampleInputEmail1" aria-describedby="emailHelp" 
      placeholder="Search"/> <i class='bx bx-search-alt search-logo' ></i>
   <?php if(Auth::user()): ?>
      <a href="<?php echo e(route('cart.products')); ?>"><span><li><i class='bx bxs-cart crt'><span id="counter1"><?php echo e(\Cart::session(Auth::user()->id)->getContent()->count()); ?></span></i></li></span></a>
  <?php else: ?>
     <a href="<?php echo e(route('cart.products')); ?>"><span><li><i class='bx bxs-cart crt'><span id="counter1"><?php echo e(\Cart::session('user')->getContent()->count()); ?></span></i></li></span></a>
  <?php endif; ?>
  <?php if(Auth::user()): ?>
  <div class="circle" id="profile-image">
    <img src="<?php echo e(URL::asset('/uploads/profile-png.png')); ?>" alt="" >
  </div>
  <?php else: ?>
  <form action="/login" method="get">
    <?php echo csrf_field(); ?>
  <button type="submit" id="login-button" class="btn btn-primary">Login</button>
  </form>
  <?php endif; ?>
  </div>
  <?php if(Auth::user()): ?>
  <div class="box">
    <div class="logout">
   <h5><?php echo e(Auth::user()->Username); ?></h5>
   <div class="divide" onclick="edit()">
   <i class='bx bx-edit' ></i><p >Edit Profile</p>
  </div>
  <div class="divide" onclick="logout()">
  <i class='bx bx-log-out'></i><p>Logout</p>
  </div>
  </div>
  </div>
  <?php endif; ?>
</div>
<?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
 <?php if(Auth::check()): ?>
 var box = document.querySelector('.box');
  var image = document.querySelector('#profile-image');
  image.addEventListener("mouseover",()=>{
    box.classList.add('active');
  });
  document.addEventListener("click",()=>{
    if ($('.box').hasClass('active') && $('.box:hover').length==0) {
    box.classList.remove('active');
    }
  });
<?php endif; ?>
  function logout() {
    location.replace("<?php echo e(route('logout')); ?>");
  }


 
</script><?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/header.blade.php ENDPATH**/ ?>