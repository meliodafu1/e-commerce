<footer>
<div class="footer">
    <span>©Mapasakatan Creator</span>
</div>
</footer>
<?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/footer.blade.php ENDPATH**/ ?>