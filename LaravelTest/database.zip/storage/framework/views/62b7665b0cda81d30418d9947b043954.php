<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('user.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Products</title>
</head>
<body>
    <div class="cont-text">
        <h4>Products</h4>
        <div class="filter">
            <span>Filters</span><i class='bx bx-filter'></i>
        </div>
        <hr>
    </div>

    <?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="products-display">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="show-products" id="show-product">
         <img src="<?php echo e(URL::asset($items->product_image)); ?>" alt="" >
         <a href="<?php echo e(url('product/'.$items->id)); ?>"><p id="g-p" ><?php echo e($items->product_name); ?></p></a>
        <span><?php echo e($items->product_status); ?></span>
         <p id="amount">P<?php echo e($items->product_price); ?></p>
         <button type="submit" id="add-cart1"  value="<?php echo e($items->id); ?>" onClick="addCart(this)"class="btn btn-dark o-btn1">Add to Cart</button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function addCart($val) {
            var product_id = $val.value;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
                });
            $.ajax({
            method: "GET",
            url: "/getCart",
            data: {
                "product_id":product_id,
                "quantity":1
            },
            success: function(response) {
                $('#counter1').html(response.count); 
                }

            });
         
        }
   
          

    </script>
</body>
</html><?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/store.blade.php ENDPATH**/ ?>