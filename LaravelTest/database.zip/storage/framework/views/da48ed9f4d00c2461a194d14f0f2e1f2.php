<?php if(session('product')): ?>
    <?php echo e(session('product')); ?>

    <?php endif; ?><?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/cart-number.blade.php ENDPATH**/ ?>