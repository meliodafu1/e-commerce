<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Information</title>
    <?php echo $__env->make('user.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="text">
        <h4>Product Information</h4>
        <hr>
    </div>
    <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product">
        <div class="product-image">
            <img src="<?php echo e(URL::asset($products->product_image)); ?>" alt="" >
        </div>
        <div class="information">
            <h4><?php echo e($products->product_name); ?></h4>
            <span id="price" >P<?php echo e($products->product_price); ?></span><br>
            <span id="stocks">( <?php echo e($products->product_stocks); ?> stocks )</span>
           
            <div class="bottom-info">
                <span id="sub-total">s</span>
                    <div class="cart-input">
                    <div class="minus" onClick="subtract()" >
                        <span>-</span>
                    </div>
                    <div class="input-text">
                        <input type="number" id="number_of_items" value='1' min='1'>
                    </div>
                    <div class="add" onClick="add()">
                        <span>+</span>
                    </div>
                </div>
                <div class="p-information-buttons">
                    <button type="submit" id="add1-cart" value="<?php echo e($products->id); ?>" name="addCart" class="btn btn-dark">Add to Cart</button>
                    <button type="button"  class="btn btn-dark">Buy Now</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="description">
        <h4>High Quality Adult Pedigree Food</h4>
        <hr>
        <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article><?php echo e($desc->product_description); ?></article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
    <div class="suggested-product">
    <h4>Products You May Like</h4>
        <hr>
        <div class="like-products">
        <?php $__currentLoopData = $featured_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="show-products" id="show-product">
                <img src="<?php echo e(URL::asset($featured->product_image)); ?>" alt="" >
                <a href="<?php echo e(url('product/'.$featured->id)); ?>"> <p><?php echo e($featured->product_name); ?></p></a>
                <span>Status: <?php echo e($featured->product_status); ?></span>
                <p id="amount">P<?php echo e($featured->product_price); ?></p>
                <button type="button" id="add-cart" class="btn btn-dark o-btn1" value="<?php echo e($featured->id); ?>">Add to Cart</button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
        var set_value = 0;
        var price_val = 0;
       $( document ).ready(function() {
        const get_buttons1 = document.querySelectorAll('#sizess')[0];
        get_buttons1.classList.add('special');
        price_val = parseInt(get_buttons1.value);
        set_value = parseInt(get_buttons1.value);
        const set_val = document.querySelector('#sub-total');
        set_val.innerHTML="Sub Total: "+set_value;
        set_val.style.visibility="visible";
        });
        const get_buttons = document.querySelectorAll('#sizess');
        get_buttons.forEach(btnEl=>{
            btnEl.addEventListener('click',()=>{
                document.querySelector('.special')?.classList.remove('special');
                btnEl.classList.add('special');
               var val =btnEl.value;
               price_val = parseInt(val);
               set_value = parseInt(val);
               var get =document.querySelector("#sub-total");
             
               get.innerHTML ="Sub Total: "+val;
               var get_count =document.querySelector("#number_of_items");
               get_count.value = 1;
            });
        })
        function subtract(){
            var counter = document.getElementById("number_of_items");
            var get_count = counter.valueAsNumber;
            if (Number.isNaN(get_count) || get_count<1) {
               counter.value = 1;
            }else {
            if (get_count!=1) {
                counter.value = get_count-=1;
                set_value-=price_val;
                var get =document.querySelector("#sub-total");
                get.innerHTML ="Sub Total: "+set_value;
            }
        }
        }
        function add(){
            var counter1 = document.getElementById("number_of_items");
            var get_count1 = counter1.valueAsNumber;
            if (Number.isNaN(get_count1)) {
               counter1.value = 1;
            }else {
            if (get_count1>=1) {
                counter1.value = get_count1+=1;
                set_value+=price_val;
                var get =document.querySelector("#sub-total");
                get.innerHTML ="Sub Total: "+set_value;
            }
        }
        }
        document.getElementById("number_of_items").addEventListener("focusout", focusOut);
        function focusOut() {
           var get_value = document.getElementById("number_of_items");
           if (get_value.valueAsNumber<1 || Number.isNaN(get_value.valueAsNumber)) {
            get_value.value = 1;
            var get =document.querySelector("#sub-total");
            get.innerHTML = "Sub Total: "+price_val;
           }

        }
    
            
    </script>
</body>
</html><?php /**PATH C:\Users\IT-DEPT01\Desktop\Laravel\LaravelTest\resources\views/user/product.blade.php ENDPATH**/ ?>