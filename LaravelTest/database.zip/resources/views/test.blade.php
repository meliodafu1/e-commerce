<div class="navbar">
  <i class='bx bxs-cat e-logo'><span>WPets</span></i>
  <ul>
    <li><a href="#home" class="tgl hver">Home</a></li>
    <li><a href="#about"  class="tgl">Product</a></li>
    <li><a href="#education" class="tgl">About</a></li>
    <li><a href="#skills" class="tgl">Contact</a></li>
  </ul>
  <div class="left">
    <input type="email" class="search-bar" id="exampleInputEmail1" aria-describedby="emailHelp" 
      placeholder="Search"/> <i class='bx bx-search-alt search-logo' ></i>
    <li><i class='bx bxs-cart crt'></i></li>
    <button type="button" id="login-button" class="btn btn-primary">Login</button>
  </div>
</div>