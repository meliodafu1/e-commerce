<footer>
<div class="footer">
    <span>©Mapasakatan Creator</span>
</div>
</footer>
